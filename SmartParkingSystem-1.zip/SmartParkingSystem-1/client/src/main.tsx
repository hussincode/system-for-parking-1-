import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Enhanced error handling - suppress known non-critical errors
// This must run BEFORE any other code to catch errors early
(function() {
  const suppressMediaErrors = (error: any) => {
    const errorMessage = error?.message || error?.toString() || String(error || "");
    return errorMessage.includes("play()") && 
           (errorMessage.includes("interrupted") || 
            errorMessage.includes("removed from the document") ||
            errorMessage.includes("was interrupted"));
  };

  // Override console.error to filter out media errors
  const originalConsoleError = console.error;
  console.error = (...args: any[]) => {
    const firstArg = args[0];
    if (suppressMediaErrors(firstArg) || suppressMediaErrors(args[1])) {
      // Suppress media-related errors
      return;
    }
    originalConsoleError.apply(console, args);
  };

  // Handle global errors
  window.addEventListener("error", (event) => {
    if (suppressMediaErrors(event.error) || suppressMediaErrors(event.message)) {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      return false;
    }
    
    // Log other errors
    console.error("Global error:", event.error);
    console.error("Error details:", {
      message: event.message,
      filename: event.filename,
      lineno: event.lineno,
      colno: event.colno,
      error: event.error,
    });
    return true;
  }, true); // Use capture phase to catch early

  // Handle unhandled promise rejections
  window.addEventListener("unhandledrejection", (event) => {
    if (suppressMediaErrors(event.reason)) {
      event.preventDefault();
      return;
    }
    
    console.error("Unhandled promise rejection:", event.reason);
  });
})();

const rootElement = document.getElementById("root");
if (!rootElement) {
  throw new Error("Root element not found");
}

try {
  createRoot(rootElement).render(<App />);
} catch (error) {
  console.error("Failed to render app:", error);
  rootElement.innerHTML = `
    <div style="padding: 20px; font-family: sans-serif;">
      <h1 style="color: red;">Failed to load application</h1>
      <pre style="background: #f5f5f5; padding: 10px; border-radius: 4px; overflow: auto;">
        ${error instanceof Error ? error.stack : String(error)}
      </pre>
    </div>
  `;
}
