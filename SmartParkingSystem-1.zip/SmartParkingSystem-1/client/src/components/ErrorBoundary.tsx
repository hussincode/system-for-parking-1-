import React from "react";

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

interface ErrorBoundaryProps {
  children: React.ReactNode;
}

class ErrorBoundary extends React.Component<
  ErrorBoundaryProps,
  ErrorBoundaryState
> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static isNonCriticalError(error: Error | null): boolean {
    if (!error) return false;
    const errorMessage = error?.message || error?.toString() || "";
    return (
      errorMessage.includes("removeChild") ||
      errorMessage.includes("play()") ||
      errorMessage.includes("interrupted") ||
      errorMessage.includes("removed from the document") ||
      errorMessage.includes("The node to be removed is not a child") ||
      (errorMessage.includes("NotAllowedError") && errorMessage.includes("camera"))
    );
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    // Check if this is a non-critical error
    if (ErrorBoundary.isNonCriticalError(error)) {
      // Return state indicating no error - the render method will handle it
      return { hasError: false, error: null };
    }
    
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    // Only log non-suppressed errors
    if (!ErrorBoundary.isNonCriticalError(error)) {
      console.error("Error caught by boundary:", error, errorInfo);
    } else {
      console.log("Non-critical error suppressed:", error.message);
    }
  }

  componentDidUpdate(prevProps: ErrorBoundaryProps, prevState: ErrorBoundaryState) {
    // If we have an error but it's non-critical, reset the state
    if (this.state.hasError && this.state.error && ErrorBoundary.isNonCriticalError(this.state.error)) {
      this.setState({ hasError: false, error: null });
    }
  }

  render() {
    // Double-check: if we somehow have a non-critical error in state, ignore it
    if (this.state.hasError && this.state.error) {
      if (ErrorBoundary.isNonCriticalError(this.state.error)) {
        return this.props.children;
      }
    }

    if (this.state.hasError && this.state.error) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-background p-4">
          <div className="max-w-md w-full space-y-4">
            <h1 className="text-2xl font-bold text-destructive">
              Something went wrong
            </h1>
            <p className="text-muted-foreground">
              {this.state.error?.message || "An unexpected error occurred"}
            </p>
            <button
              onClick={() => {
                this.setState({ hasError: false, error: null });
                window.location.reload();
              }}
              className="px-4 py-2 bg-primary text-primary-foreground rounded-md"
            >
              Reload Page
            </button>
            {this.state.error && (
              <details className="mt-4">
                <summary className="cursor-pointer text-sm text-muted-foreground">
                  Error Details
                </summary>
                <pre className="mt-2 p-4 bg-muted rounded text-xs overflow-auto">
                  {this.state.error.stack}
                </pre>
              </details>
            )}
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
