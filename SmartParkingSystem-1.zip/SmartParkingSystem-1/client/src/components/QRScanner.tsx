import { useEffect, useRef, useState } from "react";
import { Html5Qrcode } from "html5-qrcode";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Camera, CameraOff, Keyboard, AlertCircle, CheckCircle2, Info } from "lucide-react";

interface QRScannerProps {
  onScan: (qrCode: string) => Promise<void>;
}

interface CameraDevice {
  id: string;
  label: string;
}

export default function QRScanner({ onScan }: QRScannerProps) {
  const [isScanning, setIsScanning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showManualInput, setShowManualInput] = useState(false);
  const [manualCode, setManualCode] = useState("");
  const [cameraTried, setCameraTried] = useState(false);
  const [availableCameras, setAvailableCameras] = useState<CameraDevice[]>([]);
  const [selectedCameraId, setSelectedCameraId] = useState<string | null>(null);
  const [debugInfo, setDebugInfo] = useState<string>("");
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const videoStreamRef = useRef<MediaStream | null>(null);
  const qrCodeRegionId = "qr-reader";
  const isCleaningUpRef = useRef(false);
  const isMountedRef = useRef(true);

  // Cleanup function - defined early to be available in useEffect
  const cleanupScanner = async () => {
    // Prevent multiple simultaneous cleanup calls
    if (isCleaningUpRef.current) {
      return;
    }
    isCleaningUpRef.current = true;

    try {
      // First: stop all media streams to prevent play() errors
      if (videoStreamRef.current) {
        try {
          const tracks = videoStreamRef.current.getTracks();
          tracks.forEach((track) => {
            try {
              track.stop();
            } catch (e) {
              // Track might already be stopped
            }
          });
          videoStreamRef.current = null;
        } catch (e) {
          // Stream might already be stopped
        }
      }

      // Second: stop scanner (this will handle its own cleanup)
      if (scannerRef.current) {
        const scanner = scannerRef.current;
        scannerRef.current = null; // Clear reference immediately
        
        // Stop scanner in a way that won't throw errors
        try {
          // Use a very short timeout to prevent hanging
          await Promise.race([
            scanner.stop().catch(() => {
              // All stop errors are expected and can be ignored
            }),
            new Promise<void>((resolve) => setTimeout(() => resolve(), 300))
          ]);
        } catch (e) {
          // Ignore all errors
        }
        
        // Clear scanner - wrap in try-catch to prevent any errors from bubbling
        try {
          // scanner.clear() may return void, so we can't .catch() it directly.
          await Promise.race([
            (async () => {
              try {
                await scanner.clear();
              } catch {
                // All clear errors are expected
              }
            })(),
            new Promise<void>((resolve) => setTimeout(() => resolve(), 200))
          ]);
        } catch (e) {
          // Ignore all errors
        }
      }

      // Third: clean up video elements safely
      // Do this LAST and be very careful not to manipulate DOM that React controls
      try {
        const container = document.getElementById(qrCodeRegionId);
        if (container && container.isConnected) {
          // Only manipulate videos that are still in the DOM
          const videos = Array.from(container.querySelectorAll('video'));
          for (const video of videos) {
            try {
              // Check if video is still in DOM before manipulating
              if (!video.isConnected) {
                continue; // Skip if already removed
              }
              
              // Pause video
              if (!video.paused) {
                try {
                  video.pause();
                } catch {
                  // Ignore pause errors
                }
              }
              // Stop tracks
              if (video.srcObject) {
                try {
                  const stream = video.srcObject as MediaStream;
                  const tracks = stream.getTracks();
                  tracks.forEach((track) => {
                    try {
                      track.stop();
                    } catch (e) {
                      // Track might already be stopped
                    }
                  });
                  video.srcObject = null;
                } catch (e) {
                  // Ignore stream errors
                }
              }
              
              // Clear event listeners
              video.onplay = null;
              video.onpause = null;
              video.onerror = null;
              video.onloadedmetadata = null;
              video.oncanplay = null;
              
              // DON'T remove the video element - let React/HTML5Qrcode handle it
              // Removing it manually can cause "removeChild" errors
            } catch (e) {
              // Ignore all video manipulation errors
            }
          }
        }
      } catch (e) {
        // Ignore all DOM manipulation errors
        // React will handle the cleanup
      }
    } catch (error: any) {
      // Suppress ALL cleanup errors - they're expected during component unmount
      // Don't let them bubble up to ErrorBoundary
    } finally {
      isCleaningUpRef.current = false;
    }
  };

  useEffect(() => {
    isMountedRef.current = true;
    checkAvailableCameras();
    
    return () => {
      isMountedRef.current = false;
      // Cleanup on unmount
      cleanupScanner().catch(() => {});
    };
  }, []);

  const checkAvailableCameras = async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) {
        setDebugInfo("Browser doesn't support camera enumeration");
        return;
      }

      const devices = await navigator.mediaDevices.enumerateDevices();
      const videoDevices = devices
        .filter(device => device.kind === "videoinput")
        .map(device => ({
          id: device.deviceId,
          label: device.label || `Camera ${device.deviceId.substring(0, 8)}`,
        }));

      setAvailableCameras(videoDevices);
      
      if (videoDevices.length > 0 && !selectedCameraId) {
        setSelectedCameraId(videoDevices[0].id);
      }

      setDebugInfo(`Found ${videoDevices.length} camera(s)`);
    } catch (err: any) {
      console.error("Error enumerating cameras:", err);
      setDebugInfo(`Camera enumeration error: ${err.message}`);
    }
  };

  const checkCameraSupport = (): boolean => {
    const hasMediaDevices = !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
    const isSecure = window.isSecureContext || window.location.protocol === "https:" || window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1";
    
    if (!hasMediaDevices) {
      setDebugInfo("Browser doesn't support getUserMedia API");
      return false;
    }
    
    if (!isSecure) {
      setDebugInfo("Camera access requires HTTPS or localhost. Current protocol: " + window.location.protocol);
      return false;
    }
    
    return true;
  };

  const getErrorMessage = (err: any): string => {
    if (!err) return "Unknown error occurred";
    
    const errorMessage = err.message || err.toString() || String(err);
    const errorName = err.name || "";
    
    if (errorMessage.includes("Permission denied") || errorMessage.includes("NotAllowedError") || errorName === "NotAllowedError") {
      return "Camera permission denied. Please click the lock icon in your browser's address bar and allow camera access, then try again.";
    }
    
    if (errorMessage.includes("NotFoundError") || errorMessage.includes("no camera") || errorName === "NotFoundError") {
      return "No camera found. Please connect a camera or use manual input.";
    }
    
    if (errorMessage.includes("NotReadableError") || errorMessage.includes("could not start") || errorName === "NotReadableError") {
      return "Camera is being used by another application. Please close other apps using the camera (Zoom, Teams, etc.) and try again.";
    }
    
    if (errorMessage.includes("OverconstrainedError") || errorName === "OverconstrainedError") {
      return "Camera doesn't support the required settings. Trying alternative camera...";
    }
    
    if (errorMessage.includes("NotSupportedError") || errorName === "NotSupportedError") {
      return "Camera access is not supported in this browser. Please use Chrome, Firefox, or Edge.";
    }
    
    if (errorMessage.includes("HTTPS") || errorMessage.includes("secure context")) {
      return "Camera access requires a secure connection (HTTPS). Please use HTTPS or localhost.";
    }
    
    return `Camera error: ${errorMessage}. Please check browser console for details.`;
  };

  const tryStartCamera = async (cameraIdOrConfig: string | any) => {
    if (!isMountedRef.current) {
      throw new Error("Component unmounted");
    }

    await cleanupScanner();
    await new Promise(resolve => setTimeout(resolve, 200));

    if (!isMountedRef.current) {
      throw new Error("Component unmounted during cleanup");
    }

    const container = document.getElementById(qrCodeRegionId);
    if (!container || !container.isConnected) {
      throw new Error("Scanner container not found or not in DOM");
    }

    const scanner = new Html5Qrcode(qrCodeRegionId);
    scannerRef.current = scanner;

    let cameraConfig: any;
    
    if (typeof cameraIdOrConfig === "string") {
      cameraConfig = { deviceId: { exact: cameraIdOrConfig } };
    } else if (typeof cameraIdOrConfig === "object" && cameraIdOrConfig !== null) {
      cameraConfig = cameraIdOrConfig;
    } else {
      cameraConfig = true;
    }

    // Start scanner and capture the stream
    await scanner.start(
      cameraConfig,
      {
        fps: 10,
        qrbox: { width: 250, height: 250 },
        aspectRatio: 1.0,
        // 'supportedScanTypes' is not a valid option; removed for compatibility
      },
      async (decodedText) => {
        console.log("QR Code scanned:", decodedText);
        try {
          await onScan(decodedText);
        } catch (scanError) {
          console.error("Error processing scanned QR code:", scanError);
        }
      },
      () => {
        // Ignore scanning errors
      }
    );

    // Store reference to the video stream if we can get it
    try {
      const video = container.querySelector('video');
      if (video && video.srcObject) {
        videoStreamRef.current = video.srcObject as MediaStream;
        // Suppress play() errors by handling them
        video.onerror = (event: Event | string) => {
          // Suppress media errors
          if (event instanceof Event && typeof event.preventDefault === "function") {
            event.preventDefault();
          }
          return false;
        };
      }
    } catch (e) {
      // Ignore
    }

    setIsScanning(true);
    setError(null);
  };

  const startScanning = async () => {
    try {
      setError(null);
      setCameraTried(true);
      setDebugInfo("Starting camera...");
      
      if (!checkCameraSupport()) {
        throw new Error("Browser doesn't support camera access or not on secure context");
      }

      const configurations: any[] = [];
      
      if (selectedCameraId) {
        configurations.push(selectedCameraId);
      }
      
      configurations.push(
        { facingMode: "environment" },
        { facingMode: "user" },
      );
      
      if (availableCameras.length > 0) {
        availableCameras.forEach(camera => {
          if (camera.id !== selectedCameraId) {
            configurations.push(camera.id);
          }
        });
      }
      
      configurations.push(true);

      let lastError: any = null;
      let triedConfigs = 0;
      
      for (const config of configurations) {
        triedConfigs++;
        try {
          setDebugInfo(`Trying camera configuration ${triedConfigs}/${configurations.length}...`);
          await tryStartCamera(config);
          setDebugInfo("Camera started successfully!");
          return;
        } catch (err: any) {
          lastError = err;
          console.log(`Camera config ${triedConfigs} failed:`, config, "Error:", err);
          
          if (err.name === "NotAllowedError" || err.message?.includes("Permission denied")) {
            break;
          }
          
          continue;
        }
      }

      throw lastError || new Error("Failed to start camera after trying all configurations");

    } catch (err: any) {
      const errorMsg = getErrorMessage(err);
      setError(errorMsg);
      setIsScanning(false);
      setDebugInfo(`Camera start failed: ${err.message || err}`);
      console.error("Camera start error:", err);
    }
  };

  const stopScanning = async () => {
    setIsScanning(false);
    setError(null);
    setDebugInfo("Stopping camera...");
    
    await cleanupScanner();
    
    setIsScanning(false);
    setDebugInfo("Camera stopped");
  };

  const handleManualSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualCode.trim()) {
      setError("Please enter a QR code");
      return;
    }

    try {
      setError(null);
      await onScan(manualCode.trim());
      setManualCode("");
      setShowManualInput(false);
    } catch (err: any) {
      setError(err.message || "Failed to process QR code");
    }
  };

  const isSecureContext = window.isSecureContext || 
    window.location.protocol === "https:" || 
    window.location.hostname === "localhost" || 
    window.location.hostname === "127.0.0.1";

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {!isSecureContext && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Security Warning</AlertTitle>
          <AlertDescription>
            Camera access requires a secure connection (HTTPS) or localhost. 
            Current URL: {window.location.protocol}//{window.location.hostname}
          </AlertDescription>
        </Alert>
      )}

      <Card className="p-6">
        <div
          id={qrCodeRegionId}
          className="w-full aspect-video rounded-lg overflow-hidden bg-muted flex items-center justify-center"
          data-testid="div-qr-scanner"
        >
          {!isScanning && !showManualInput && (
            <div className="text-center text-muted-foreground p-8">
              <Camera className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p className="text-sm">Camera preview will appear here</p>
            </div>
          )}
        </div>

        {error && (
          <Alert variant="destructive" className="mt-4" data-testid="text-error">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {!error && isScanning && (
          <Alert className="mt-4">
            <CheckCircle2 className="h-4 w-4" />
            <AlertTitle>Scanning...</AlertTitle>
            <AlertDescription>Point your camera at the QR code</AlertDescription>
          </Alert>
        )}

        {debugInfo && process.env.NODE_ENV === "development" && (
          <Alert className="mt-2">
            <Info className="h-4 w-4" />
            <AlertDescription className="text-xs">{debugInfo}</AlertDescription>
          </Alert>
        )}
      </Card>

      {showManualInput ? (
        <Card className="p-6">
          <form onSubmit={handleManualSubmit} className="space-y-4">
            <div>
              <label htmlFor="manual-qr" className="text-sm font-medium mb-2 block">
                Enter QR Code Manually
              </label>
              <Input
                id="manual-qr"
                type="text"
                placeholder="Enter QR code value (e.g., CAR-1234567890-abc123)"
                value={manualCode}
                onChange={(e) => setManualCode(e.target.value)}
                className="w-full"
                autoFocus
              />
            </div>
            <div className="flex gap-2">
              <Button type="submit" className="flex-1">
                Submit QR Code
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setShowManualInput(false);
                  setManualCode("");
                  setError(null);
                }}
              >
                Cancel
              </Button>
            </div>
          </form>
        </Card>
      ) : (
        <div className="flex flex-col gap-4">
          {availableCameras.length > 1 && !isScanning && (
            <Card className="p-4">
              <label className="text-sm font-medium mb-2 block">
                Select Camera:
              </label>
              <select
                value={selectedCameraId || ""}
                onChange={(e) => setSelectedCameraId(e.target.value)}
                className="w-full h-9 rounded-md border border-input bg-background px-3 py-1 text-sm"
              >
                {availableCameras.map((camera) => (
                  <option key={camera.id} value={camera.id}>
                    {camera.label}
                  </option>
                ))}
              </select>
            </Card>
          )}

          <div className="flex gap-4">
            {!isScanning ? (
              <>
                <Button
                  onClick={startScanning}
                  className="flex-1"
                  data-testid="button-start-scan"
                  disabled={!isSecureContext}
                >
                  <Camera className="w-4 h-4 mr-2" />
                  Start Camera Scan
                </Button>
                <Button
                  onClick={() => {
                    setShowManualInput(true);
                    setError(null);
                  }}
                  variant="outline"
                  className="flex-1"
                >
                  <Keyboard className="w-4 h-4 mr-2" />
                  Enter Manually
                </Button>
              </>
            ) : (
              <Button
                onClick={stopScanning}
                variant="destructive"
                className="flex-1"
                data-testid="button-stop-scan"
              >
                <CameraOff className="w-4 h-4 mr-2" />
                Stop Scanning
              </Button>
            )}
          </div>

          {cameraTried && error && (
            <Button
              onClick={() => {
                setShowManualInput(true);
                setError(null);
              }}
              variant="outline"
              className="w-full"
            >
              <Keyboard className="w-4 h-4 mr-2" />
              Enter QR Code Manually Instead
            </Button>
          )}
        </div>
      )}

      <Card className="p-4 bg-muted/50">
        <h3 className="text-sm font-semibold mb-2">Camera Troubleshooting:</h3>
        <ul className="text-xs text-muted-foreground space-y-1 list-disc list-inside">
          <li>Ensure you're on HTTPS or localhost (required for camera access)</li>
          <li>Click "Allow" when your browser prompts for camera permission</li>
          <li>Check browser settings: Click the lock icon in the address bar → Site settings → Camera → Allow</li>
          <li>Close other applications that might be using the camera (Zoom, Teams, etc.)</li>
          <li>Make sure your camera is connected and not being used by another app</li>
          <li>Try a different browser (Chrome, Firefox, or Edge work best)</li>
          <li>If camera doesn't work, use the "Enter Manually" option</li>
        </ul>
      </Card>
    </div>
  );
}
